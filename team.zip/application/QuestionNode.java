package application;

import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class QuestionNode {
    
    private VBox node;
    private ToggleGroup choices;
    
    public QuestionNode(Question q) {
        
    }
    
    public VBox getNode() {
        return this.node;
    }
    
    public ToggleGroup getChoices() {
        return this.choices;
    }
}
