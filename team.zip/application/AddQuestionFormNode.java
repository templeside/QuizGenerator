package application;

import java.io.FileReader;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class AddQuestionFormNode {
    
    private List<TextField> choiceTexts;
    private List<ToggleGroup> choiceGroups;
    private VBox form;
    
    public AddQuestionFormNode() {       
        choiceTexts = null;
        choiceGroups = null;
        form = null;
    }
    
    public TextField getMetadata() {
        TextField textField = new TextField("Metadata");
        return textField;
        
    }
    
    public TextField getQuestion() {
        TextField textField = new TextField("Question");
        return textField;
               
    }
    
    public TextField getTopic() {
        TextField textField = new TextField("topic");
        return textField;
        
    }

    public TextField getImage() {
        TextField textField = new TextField("image");
        return textField;
        
    }
    
    public List<TextField> getChoiceTexts() {
        return choiceTexts;
        
    }
    
    public VBox getNode() {
        return form;
        
    }
    
    public List<ToggleGroup> getChoiceGroups() {
        return choiceGroups;
        
    }
}
