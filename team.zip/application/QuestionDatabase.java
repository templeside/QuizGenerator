package application;

import java.io.File;
import java.util.List;
import java.util.Map;
import javafx.collections.ObservableList;

public class QuestionDatabase implements QuestionDatabaseADT {

    private Map<String, List<Question>> topics;

    public QuestionDatabase() {
        topics = null;
    }

    public void addQuestion() {
        
    }

    public int getNumQuestions() {
        return 0;
    }

    public void saveQuestionsToJSON(File file) {

    }

    public List<Question> getQuestions(String name) {
        return null;

    }

    public void loadQuestionsFromJSON(File file) {

    }

    public ObservableList<String> getTopics() {
        return null;

    }
}
